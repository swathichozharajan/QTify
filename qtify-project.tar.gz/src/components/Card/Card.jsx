import React from "react";
import { Chip } from "@mui/material";
import styles from "./Card.module.css";

function Card({ data, type = "album" }) {
  const count = type === "song" ? data.likes : data.follows;
  const label = type === "song" ? "Likes" : "Follows";

  return (
    <div className={styles.card}>
      <div className={styles.imageContainer}>
        <img
          src={data.image}
          alt={data.title}
          className={styles.image}
        />

        <Chip
          label={`${count || 0} ${label}`}
          className={styles.chip}
          size="small"
        />
      </div>

      <div className={styles.details}>
        <p className={styles.title}>{data.title}</p>
      </div>
    </div>
  );
}

export default Card;