import React, { useEffect, useState } from "react";
import axios from "axios";
import { Tabs, Tab } from "@mui/material";

import Card from "../Card/Card";
import Carousel from "../Carousel/Carousel";
import styles from "./Songs.module.css";

function Songs() {
  const [songs, setSongs] = useState([]);
  const [genres, setGenres] = useState([]);
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSongsAndGenres = async () => {
      try {
        const [songsResponse, genresResponse] = await Promise.all([
          axios.get("https://qtify-backend.labs.crio.do/songs"),
          axios.get("https://qtify-backend.labs.crio.do/genres"),
        ]);

        const songData = songsResponse.data;
        const genreData = genresResponse.data;

        setSongs(
          Array.isArray(songData) ? songData : songData.data || []
        );

        setGenres(
          Array.isArray(genreData) ? genreData : genreData.data || []
        );
      } catch (error) {
        console.error("Unable to fetch songs or genres:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSongsAndGenres();
  }, []);

  const filteredSongs =
    selectedGenre === "all"
      ? songs
      : songs.filter((song) => {
          const songGenre =
            typeof song.genre === "object"
              ? song.genre.key
              : song.genre;

          return songGenre === selectedGenre;
        });

  return (
    <section className={styles.section}>
      <div className={styles.header}>
        <h2>Songs</h2>
      </div>

      <div className={styles.tabsContainer}>
        <Tabs
          value={selectedGenre}
          onChange={(event, newValue) => setSelectedGenre(newValue)}
          className={styles.tabs}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="All" value="all" />

          {genres.filter((genre) => genre.key !== "all").map((genre) => (
            <Tab
              key={genre.key}
              label={genre.label}
              value={genre.key}
            />
          ))}
        </Tabs>
      </div>

      {loading ? (
        <p>Loading songs...</p>
      ) : filteredSongs.length === 0 ? (
        <p>No songs available for this genre.</p>
      ) : (
        <Carousel
          items={filteredSongs}
          renderItem={(song) => (
            <Card data={song} type="song" />
          )}
        />
      )}
    </section>
  );
}

export default Songs;