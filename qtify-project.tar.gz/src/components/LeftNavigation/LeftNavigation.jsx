import React from "react";

function LeftNavigation({ onClick, disabled }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label="Previous"
      style={{
        border: "none",
        borderRadius: "50%",
        width: "40px",
        height: "40px",
        cursor: disabled ? "default" : "pointer",
        backgroundColor: "#ffffff",
        fontSize: "24px",
        opacity: disabled ? 0.4 : 1,
      }}
    >
      &#8249;
    </button>
  );
}

export default LeftNavigation;