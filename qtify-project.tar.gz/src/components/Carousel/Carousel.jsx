import React, { useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";

import LeftNavigation from "../LeftNavigation/LeftNavigation";
import RightNavigation from "../RightNavigation/RightNavigation";
import styles from "./Carousel.module.css";

function Carousel({ items = [], renderItem }) {
  const swiperRef = useRef(null);
  const [isBeginning, setIsBeginning] = useState(true);
  const [isEnd, setIsEnd] = useState(false);

  const updateNavigation = (swiper) => {
    setIsBeginning(swiper.isBeginning);
    setIsEnd(swiper.isEnd);
  };

  return (
    <div className={styles.carousel}>
      <div className={styles.navigation}>
        <LeftNavigation
          disabled={isBeginning}
          onClick={() => swiperRef.current?.slidePrev()}
        />

        <RightNavigation
          disabled={isEnd}
          onClick={() => swiperRef.current?.slideNext()}
        />
      </div>

      <Swiper
        onSwiper={(swiper) => {
          swiperRef.current = swiper;
          updateNavigation(swiper);
        }}
        onSlideChange={updateNavigation}
        onResize={updateNavigation}
        spaceBetween={20}
        slidesPerView="auto"
        breakpoints={{
          320: { spaceBetween: 12 },
          600: { spaceBetween: 16 },
          900: { spaceBetween: 20 },
        }}
      >
        {items.map((item, index) => (
          <SwiperSlide key={item.id || index} className={styles.slide}>
            {renderItem(item)}
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

export default Carousel;