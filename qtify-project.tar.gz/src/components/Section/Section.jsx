import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "../Card/Card";
import Carousel from "../Carousel/Carousel";
import styles from "./Section.module.css";

function Section({
  title,
  endpoint,
  type = "album",
  showToggle = true,
}) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showGrid, setShowGrid] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await axios.get(endpoint);
        const result = response.data;

        setItems(Array.isArray(result) ? result : result.data || []);
      } catch (error) {
        console.error(`Unable to fetch ${title}:`, error);
      } finally {
        setLoading(false);
      }
    };

    fetchItems();
  }, [endpoint, title]);

  const renderCard = (item) => (
    <Card data={item} type={type} />
  );

  return (
    <section className={styles.section}>
      <div className={styles.sectionHeader}>
        <h2>{title}</h2>

        {showToggle && (
          <button
            className={styles.toggleButton}
            onClick={() => setShowGrid(!showGrid)}
          >
            {showGrid ? "Collapse" : "Show All"}
          </button>
        )}
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : items.length === 0 ? (
        <p>No data available.</p>
      ) : showGrid || !showToggle ? (
        <div className={styles.grid}>
          {items.map((item, index) => (
            <div key={item.id || index}>
              {renderCard(item)}
            </div>
          ))}
        </div>
      ) : (
        <Carousel items={items} renderItem={renderCard} />
      )}
    </section>
  );
}

export default Section;